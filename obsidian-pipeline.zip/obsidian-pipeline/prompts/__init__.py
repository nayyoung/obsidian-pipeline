# Prompts package for Obsidian Mind Map Pipeline
